export enum TxStatus {
    SUCCESS = "SUCCESS",
    ERROR = "ERROR",
}
